#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include "raylib.h"

#define NB_WORDS 10
#define NB_GAME_MODE 3

typedef struct List List;
typedef struct Setting Setting;

struct List {

    Setting *first;
    Setting *last;
    int nbValue;
};

struct Setting {

    char stringLanguage[10];
    char stringLevel[10];
    char stringTheme[10];
    Setting *next;
    Setting *previous;
};

typedef enum {
    STATE_MENU,
    STATE_SETTING,
    STATE_CHOICE_MODE,
    STATE_CLASSIC,
    STATE_CLOCK,
    STATE_NAME_SELECTION_CLASSIC,
    STATE_NAME_SELECTION_CLOCK,
    NONE
} GameState;

#ifndef HANGMAN_H_INCLUDED
#define HANGMAN_H_INCLUDED

extern const char *level[];
extern const char *themes[];
extern const char *languages[];

List *initialisationList();
int freeList(List *list);
int selectionSetting(List *list, int *difficulty, int *theme, int *language);
int createDoubleLinkedStack(List *list, int nb);
int saveUserAndPoint( char* userName, int point);
int readLetter(char* word, char letter);
int getScore();
int addPointAfterGuessRight(int count);
void displayDoubleLinkedStack(List *list);
void generate_filename(char *filename, int difficulty, int theme, int language);
char* displayDifficultyAtIndex(List *list, int index);
char* displayLanguageAtIndex(List *list, int index);
char* displayThemeAtIndex(List *list, int index);
char* chooseWordRandom(FILE *file);
char* replaceWithDashes(const char* word);
char* showHiddenWord(char* word, char letterGuessed, char dash[]);
char* checkInputNameClassic(bool mouseOnText, Rectangle textBox, GameState *currentState);
char* checkInputNameClock(bool mouseOnText, Rectangle textBox, GameState *currentState);
char* replaceWithDashesRight(const char* word, char *dashes, char letter);

#endif